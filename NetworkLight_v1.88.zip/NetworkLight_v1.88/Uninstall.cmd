@echo off
setlocal
if not exist "%~dp0Uninstall.exe" goto missing
:choose
set "nlTemp=%TEMP%\NetworkLight-Uninstall-%RANDOM%-%RANDOM%"
if exist "%nlTemp%" goto choose
mkdir "%nlTemp%"
if errorlevel 1 goto failed
copy /y "%~dp0Uninstall.exe" "%nlTemp%\Uninstall.exe" >nul
if errorlevel 1 goto failed
cd /d "%TEMP%"
rem The whole block is parsed before the uninstaller may delete this launcher.
(
 start "" /wait "%nlTemp%\Uninstall.exe" "%~dp0."
 if errorlevel 1 (
  del /q "%nlTemp%\Uninstall.exe"
  rd "%nlTemp%"
  exit /b 1
 )
 del /q "%nlTemp%\Uninstall.exe"
 rd "%nlTemp%"
 exit /b 0
)
:missing
echo Uninstaller is missing. Reinstall NetworkLight 1.88 to restore it.
pause
exit /b 1
:failed
echo Cannot prepare the uninstaller in the temporary folder.
pause
exit /b 1
