﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

internal sealed class AppMenu:ContextMenuStrip {
 readonly Form window;
 internal AppMenu(System.ComponentModel.IContainer owner,Form form):base(owner){window=form;AutoClose=true;}
 internal static Point Clamp(Rectangle area,Size size,Point p){return new Point(Math.Max(area.Left,Math.Min(p.X,area.Right-size.Width)),Math.Max(area.Top,Math.Min(p.Y,area.Bottom-size.Height)));}
 protected override void OnOpening(System.ComponentModel.CancelEventArgs e){MaximumSize=Screen.FromControl(window).WorkingArea.Size;base.OnOpening(e);}
 protected override void OnOpened(EventArgs e){Location=Clamp(Screen.FromControl(window).WorkingArea,Size,Location);base.OnOpened(e);}
 internal static void VerifyBounds(){foreach(var area in new[]{new Rectangle(-1920,0,1920,1040),new Rectangle(0,0,1920,1040),new Rectangle(1920,-200,1280,900)})foreach(var p in new[]{new Point(area.Right+100,area.Bottom),new Point(area.Left-100,area.Top-100)}){var size=new Size(400,300);var r=new Rectangle(Clamp(area,size,p),size);if(!area.Contains(r))throw new Exception("Menu outside application display");}}
}
internal static class ButtonLook {
 internal static Color Hover(Color c){return Color.FromArgb(Math.Min(255,c.R+32),Math.Min(255,c.G+36),Math.Min(255,c.B+40));}
 internal static void Apply(Button b){b.UseVisualStyleBackColor=false;Action update=()=>{b.FlatAppearance.MouseOverBackColor=Hover(b.BackColor);b.FlatAppearance.MouseDownBackColor=Color.FromArgb(Math.Max(0,b.BackColor.R-14),Math.Max(0,b.BackColor.G-14),Math.Max(0,b.BackColor.B-14));};update();b.BackColorChanged+=(s,e)=>update();b.MouseEnter+=(s,e)=>b.FlatAppearance.BorderColor=Color.FromArgb(166,196,220);b.MouseLeave+=(s,e)=>b.FlatAppearance.BorderColor=Color.FromArgb(105,125,149);}
}
internal sealed class SplitActionButton:Button {
 internal event Action MenuRequested;readonly Action primary;bool over,pressed,arrowClick;
 internal SplitActionButton(string text,Action action){Text=text;primary=action;AutoSize=true;FlatStyle=FlatStyle.Flat;SetStyle(ControlStyles.UserPaint|ControlStyles.OptimizedDoubleBuffer,true);AccessibleName=text;AccessibleDescription="Основная часть: "+text+". Стрелка или Alt+Вниз: "+text+" всех.";}
 int ArrowWidth{get{return Math.Max(24,Font.Height+12);}}
 public override Size GetPreferredSize(Size proposed){return new Size(TextRenderer.MeasureText(Text,Font).Width+ArrowWidth+30,Math.Max(34,Font.Height+16));}
 protected override void OnMouseEnter(EventArgs e){over=true;Invalidate();base.OnMouseEnter(e);}
 protected override void OnMouseLeave(EventArgs e){over=false;pressed=false;Invalidate();base.OnMouseLeave(e);}
 protected override void OnMouseDown(MouseEventArgs e){arrowClick=e.Button==MouseButtons.Left&&e.X>=Width-ArrowWidth;pressed=true;Invalidate();base.OnMouseDown(e);}
 protected override void OnMouseUp(MouseEventArgs e){pressed=false;Invalidate();base.OnMouseUp(e);arrowClick=false;}
 protected override void OnClick(EventArgs e){if(arrowClick){if(MenuRequested!=null)MenuRequested();}else primary();base.OnClick(e);}
 protected override void OnKeyDown(KeyEventArgs e){arrowClick=false;if(e.KeyCode==Keys.Down&&(e.Alt||e.Modifiers==Keys.None)){if(MenuRequested!=null)MenuRequested();e.Handled=true;e.SuppressKeyPress=true;}else base.OnKeyDown(e);}
 protected override void OnPaint(PaintEventArgs e){Color fill=over?ButtonLook.Hover(BackColor):BackColor;if(pressed)fill=ControlPaint.Dark(fill,.10f);e.Graphics.Clear(fill);using(var border=new Pen(over?Color.FromArgb(166,196,220):Color.FromArgb(105,125,149),2)){e.Graphics.DrawRectangle(border,1,1,Width-2,Height-2);e.Graphics.DrawLine(border,Width-ArrowWidth,3,Width-ArrowWidth,Height-4);}TextRenderer.DrawText(e.Graphics,Text,Font,new Rectangle(2,2,Width-ArrowWidth-4,Height-4),ForeColor,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter);int x=Width-ArrowWidth/2,y=Height/2;using(var brush=new SolidBrush(ForeColor))e.Graphics.FillPolygon(brush,new[]{new Point(x-4,y-2),new Point(x+4,y-2),new Point(x,y+3)});if(Focused)ControlPaint.DrawFocusRectangle(e.Graphics,new Rectangle(5,5,Width-ArrowWidth-10,Height-10),ForeColor,fill);}
}
internal sealed class MonitorHeader:Panel {
 readonly Control[] items;bool arranging;
 internal MonitorHeader(params Control[] controls){items=controls;DoubleBuffered=true;foreach(var c in items){c.AutoSize=false;c.Margin=Padding.Empty;Controls.Add(c);}}
 int U(int x){return Math.Max(1,(int)Math.Ceiling(x*Font.Height/17.0));}
 int WidthOf(int i){return TextRenderer.MeasureText(items[i].Text,items[i].Font).Width+U(i==0?4:24);}
 int H(){int h=U(40);foreach(var c in items)h=Math.Max(h,c.Font.Height+U(14));return h;}
 public override Size GetPreferredSize(Size proposed){return items==null?base.GetPreferredSize(proposed):new Size(0,H()+U(24));}
 protected override void OnLayout(LayoutEventArgs e){base.OnLayout(e);if(items==null||arranging)return;arranging=true;try{int edge=U(16),gap=U(8),h=H(),x=edge;for(int i=0;i<3;i++){int w=WidthOf(i);items[i].SetBounds(x,U(12),w,h);x+=w+gap;}int info=U(42);items[4].SetBounds(ClientSize.Width-edge-info,U(12),info,h);
 int pinWidth=WidthOf(5)+U(8);items[5].SetBounds(items[4].Left-gap-pinWidth,U(12),pinWidth,h);
 int middle=ClientSize.Width/2;int width=Math.Min(U(300),2*Math.Min(middle-x,items[5].Left-gap-middle));if(width<U(60)){width=Math.Max(0,items[5].Left-gap-x);items[3].SetBounds(x,U(12),width,h);}else items[3].SetBounds(middle-width/2,U(12),width,h);
 }finally{arranging=false;}}
}
// Samples keep their original shape and state; painting never regenerates history.
internal sealed class PulseHistory {
 internal struct Sample {internal double Time,Value;internal int Mode;}
 readonly Sample[] buffer=new Sample[802];int start,count;double remainder,time;
 internal int Count{get{return count;}}internal double Time{get{return time;}}
 internal void Clear(){start=count=0;remainder=0;}
 internal Sample At(int i){return buffer[(start+i)%buffer.Length];}
 internal void Advance(double elapsed,int mode){remainder+=Math.Max(0,Math.Min(.25,elapsed));while(remainder>=.01){remainder-=.01;time+=.01;var sample=new Sample{Time=time,Value=Wave(time,mode),Mode=mode};if(count==buffer.Length){buffer[start]=sample;start=(start+1)%buffer.Length;}else{buffer[(start+count)%buffer.Length]=sample;count++;}}}
 static double Bump(double x,double center,double spread){double t=(x-center)/spread;return Math.Exp(-t*t);}
 static double Beat(double p){return .20*Bump(p,.18,.035)-.25*Bump(p,.26,.020)+Bump(p,.31,.022)-.75*Bump(p,.37,.025)+.22*Bump(p,.55,.055);}
 static double RandomBeat(long beat,int salt){unchecked{uint x=(uint)beat^(uint)salt;x^=x>>16;x*=0x7feb352d;x^=x>>15;x*=0x846ca68b;x^=x>>16;return x/(double)uint.MaxValue;}}
 static double Wave(double t,int mode){if(mode==0)return 0;if(mode==5){double p=t-Math.Floor(t);return .045*Math.Sin(t*29)+.026*Math.Sin(t*47.3)+.02*Math.Sin(t*71.1)+.13*Bump(p,.23+.08*Math.Sin(Math.Floor(t)*2.3),.045);}
 double cycle=t/2;long beat=(long)Math.Floor(cycle);double phase=cycle-Math.Floor(cycle);double v=Beat(phase);if((mode==3||mode==4)&&RandomBeat(beat,721)<.30){double scale=RandomBeat(beat,137)<.5?.35+RandomBeat(beat,291)*.25:1.35+RandomBeat(beat,291)*.65;double warped=phase+.13*Math.Sin(phase*2*Math.PI)+.045*Math.Sin(phase*6*Math.PI);v=Beat(warped)*scale+.30*Bump(phase,.68,.025)-.23*Bump(phase,.75,.018);v+=.06*Math.Sin(t*31)*Math.Sin(phase*Math.PI);}return v;}
 internal static void Verify(){var h=new PulseHistory();for(int i=0;i<40;i++)h.Advance(.04,1);var old=h.At(50);h.Advance(.04,5);var retained=h.At(50);if(old.Time!=retained.Time||old.Value!=retained.Value||retained.Mode!=1||h.At(h.Count-1).Mode!=5)throw new Exception("Pulse history changed on outage");for(int i=0;i<240;i++)h.Advance(.04,5);if(h.Count!=802||h.At(0).Mode!=5)throw new Exception("Pulse history did not expire");var before=h.At(100);h.Advance(.04,1);bool found=false;for(int i=0;i<h.Count;i++){var s=h.At(i);if(s.Time==before.Time){found=true;if(s.Value!=before.Value||s.Mode!=5)throw new Exception("Pulse history changed on recovery");}}if(!found||h.At(h.Count-1).Mode!=1)throw new Exception("Missing recovery samples");}
}
internal sealed class PulseStrip:Control {
 readonly Timer frames=new Timer();readonly System.Diagnostics.Stopwatch clock=new System.Diagnostics.Stopwatch();readonly PulseHistory history=new PulseHistory();int state;double stoppedAt=-10;
 internal PulseStrip(){SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer,true);frames.Interval=40;frames.Tick+=(s,e)=>{Advance();Invalidate();UpdateTimer();};VisibleChanged+=(s,e)=>UpdateTimer();}
 void Advance(){if(!clock.IsRunning)return;double elapsed=clock.Elapsed.TotalSeconds;clock.Restart();history.Advance(elapsed,state);}
 void UpdateTimer(){bool active=Visible&&(state!=0||history.Time-stoppedAt<8.1);if(active&&!frames.Enabled){clock.Restart();frames.Start();}else if(!active&&frames.Enabled){frames.Stop();clock.Reset();}}
 internal void SetState(int total,int down,bool losses){int next=total==0?0:down==total?5:down*2>=total?4:down>0?3:losses?2:1;if(next==state)return;Advance();state=next;if(next==0)stoppedAt=history.Time;UpdateTimer();Invalidate();}
 protected override void Dispose(bool disposing){if(disposing){frames.Dispose();clock.Stop();}base.Dispose(disposing);}
 static Color Ink(int mode){return mode==0?Color.SlateGray:mode>=3?Color.Tomato:mode==2?Color.Gold:Color.LimeGreen;}
 static long Sweep(double time){return (long)Math.Round(time*100)/800;}
 PointF Position(PulseHistory.Sample s,float width){float x=(float)((Math.Round(s.Time*100)%800)/799*width);float y=(float)(Height*.5-s.Value*Height*.35);return new PointF(x,Math.Max(3,Math.Min(Height-4,y)));}
 protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);if(Width<2||Height<2)return;var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;g.Clear(Color.FromArgb(19,28,36));float head=Width-4;
 using(var grid=new Pen(Color.FromArgb(35,52,58))){for(int x=0;x<Width;x+=20)g.DrawLine(grid,x,0,x,Height);g.DrawLine(grid,0,Height/2,Width,Height/2);}
 using(var glow=new Pen(Color.Transparent,6))using(var pen=new Pen(Color.Transparent,2.6f)){pen.StartCap=pen.EndCap=LineCap.Round;for(int i=1;i<history.Count;i++){var sample=history.At(i);var previous=history.At(i-1);var a=Position(previous,head);var b=Position(sample,head);if(sample.Mode==0||previous.Mode==0||Sweep(sample.Time)!=Sweep(previous.Time))continue;double opacity=Math.Max(0,1-(history.Time-sample.Time)/7);if(opacity<=0)continue;var color=Ink(sample.Mode);glow.Color=Color.FromArgb((int)(50*opacity),color);pen.Color=Color.FromArgb((int)(255*opacity),color);g.DrawLine(glow,a,b);g.DrawLine(pen,a,b);}}
 if(history.Count>0&&state!=0){var point=Position(history.At(history.Count-1),head);using(var halo=new SolidBrush(Color.FromArgb(70,Ink(state))))g.FillEllipse(halo,point.X-4,point.Y-4,8,8);using(var dot=new SolidBrush(Ink(state)))g.FillEllipse(dot,point.X-1.8f,point.Y-1.8f,3.6f,3.6f);}
 if(state==0&&history.Time-stoppedAt>=8)TextRenderer.DrawText(g,"Опрос остановлен",Font,ClientRectangle,Color.SlateGray,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter);
 }
}
