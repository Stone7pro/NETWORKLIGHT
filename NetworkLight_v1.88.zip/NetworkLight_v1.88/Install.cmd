@echo off
setlocal
cd /d "%~dp0"
echo Preparing NetworkLight 1.88 setup...
set "nlCompiler=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%nlCompiler%" set "nlCompiler=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%nlCompiler%" goto noframework
if not exist "build" mkdir "build"
if not exist "build" goto fail
"%nlCompiler%" /nologo /codepage:65001 /target:winexe /platform:anycpu /win32manifest:NetworkLight.manifest /win32icon:NetworkLight.ico /optimize+ /out:"build\NetworkLight.exe" /reference:System.dll /reference:System.Core.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll /reference:System.Xml.dll /reference:System.Security.dll NetworkLight.cs Toolbar.cs CellFeedback.cs PinWindow.cs Ordering.cs Names.cs ImportNodes.cs Editing.cs Visuals.cs Alarm.cs Options.cs AssemblyInfo.cs SelfTests.cs OutageBatch.cs Mail.cs MailUI.cs
if errorlevel 1 goto fail
"%nlCompiler%" /nologo /codepage:65001 /target:winexe /main:SetupProgram /win32manifest:NetworkLight.manifest /win32icon:NetworkLight.ico /out:"build\Setup.exe" /reference:System.dll /reference:System.Core.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll Setup.cs ShellLinks.cs AssemblyInfo.cs
if errorlevel 1 goto fail
"%nlCompiler%" /nologo /codepage:65001 /target:winexe /main:UninstallProgram /win32manifest:NetworkLight.manifest /win32icon:Uninstall.ico /out:"build\Uninstall.exe" /reference:System.dll /reference:System.Core.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll Setup.cs ShellLinks.cs AssemblyInfo.cs
if errorlevel 1 goto fail
for %%F in (NetworkLight.exe.config NetworkLight.ico Uninstall.ico Uninstall.cmd) do (
 copy /y "%%F" "build\%%F" >nul
 if errorlevel 1 goto fail
)
start "" /wait "build\NetworkLight.exe" --self-test
if errorlevel 1 goto testfail
start "" /wait "build\Setup.exe" --self-test
if errorlevel 1 goto setuptestfail
start "" /wait "build\Setup.exe"
if errorlevel 1 goto fail
exit /b 0
:noframework
echo .NET Framework 4.8 and its C# compiler are required.
goto fail
:setuptestfail
echo Setup tests failed. See build\setup-test-error.txt
goto fail
:testfail
echo Built-in tests failed. See build\self-test-error.txt
:fail
echo Preparation failed. Read the error above. Keep antivirus protection enabled.
pause
exit /b 1
