﻿using System;
using System.Drawing;
using System.Windows.Forms;
namespace NetworkLight {
public partial class MainForm {
 bool nameLayoutPending;
 void FitName(Node n){nameLayoutPending=true;}
 void FlushNameLayout(){if(!nameLayoutPending||grid.IsCurrentCellInEditMode)return;nameLayoutPending=false;foreach(var n in nodes)FitNameNow(n);}
 void FitNameNow(Node n){if(n.Row==null||!grid.Columns[13].Visible)return;int width=Math.Max(30,grid.Columns[13].Width-22);var size=TextRenderer.MeasureText(n.Target.Comment??"",grid.Font,new Size(width,1000),TextFormatFlags.WordBreak|TextFormatFlags.NoPrefix);int height=Math.Min(1000,Math.Max(38,size.Height+18));if(n.Row.Height<height)n.Row.Height=height;}
}
}
