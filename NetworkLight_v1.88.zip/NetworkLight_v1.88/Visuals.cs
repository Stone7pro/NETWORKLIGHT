﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Media;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace NetworkLight {
public sealed class MonitorGrid:DataGridView { public MonitorGrid(){DoubleBuffered=true;}
 bool NameBreak(Keys key){if(key==(Keys.Shift|Keys.Enter)&&IsCurrentCellInEditMode&&CurrentCell.ColumnIndex==13){var box=EditingControl as TextBox;if(box!=null){box.SelectedText=Environment.NewLine;return true;}}return false;}
 protected override bool ProcessDialogKey(Keys keyData){return NameBreak(keyData)||base.ProcessDialogKey(keyData);}
 protected override bool ProcessDataGridViewKey(KeyEventArgs e){return NameBreak(e.KeyData)||base.ProcessDataGridViewKey(e);}
 }
public sealed class ResponseGraph:Control {
 public Node Node;
 public ResponseGraph(){DoubleBuffered=true;ResizeRedraw=true;BackColor=Color.FromArgb(18,25,35);ForeColor=Color.White;Font=new Font("Segoe UI",9);}
 static List<Sample> Compact(List<Sample> input,int pixels){if(input.Count<=pixels)return input;var result=new List<Sample>(pixels);for(int bin=0;bin<pixels;bin++){int start=bin*input.Count/pixels,end=(bin+1)*input.Count/pixels;bool good=true;long peak=0;for(int i=start;i<end;i++){good&=input[i].Good;peak=Math.Max(peak,input[i].Rtt);}var latest=input[end-1];result.Add(new Sample{Time=latest.Time,Wall=latest.Wall,Rtt=peak,Good=good});}return result;}
 protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;
  string title=Node==null?"Выберите узел для просмотра графика":"Результатов: "+Math.Min(Node.Samples.Count,Node.Target.GraphCount)+" / "+Node.Target.GraphCount+"   •   "+Node.Target.Host+" / "+Node.Target.Mode+"   •   Время ответа, мс";
  g.DrawString(title,Font,Brushes.White,12,8);if(Width<160||Height<85)return;
  var r=new RectangleF(14,34,Width-100,Height-68);if(r.Height<10||r.Width<10)return;
  var samples=Node==null?new List<Sample>():Compact(Node.Samples.Snapshot(),Math.Max(32,(int)r.Width));
  double max=Math.Max(10,samples.Where(p=>p.Good).Select(p=>(double)p.Rtt).DefaultIfEmpty(10).Max()*1.15);max=Math.Ceiling(max/10)*10;
  using(var pen=new Pen(Color.FromArgb(85,105,125),1.5F))for(int i=0;i<=4;i++){float y=r.Bottom-r.Height*i/4;g.DrawLine(pen,r.Left,y,r.Right,y);g.DrawString((max*i/4).ToString("0"),Font,Brushes.Silver,r.Right+6,y-7);}
  if(samples.Count==0){g.DrawString("Нет результатов опроса",Font,Brushes.Silver,r.Left+12,r.Top+10);return;}
  double half=Math.Max(100,Node.Target.Interval/2.0);double from=samples[0].Time-half,to=samples[samples.Count-1].Time+half;double span=Math.Max(1,to-from);
  Func<double,float> x=t=>r.Left+(float)((t-from)/span*r.Width);Func<long,float> yval=t=>r.Bottom-(float)(t/max*r.Height);
  using(var green=new SolidBrush(Color.FromArgb(145,20,145,82)))using(var red=new SolidBrush(Color.FromArgb(195,184,35,46)))using(var curve=new Pen(Color.FromArgb(110,255,174),3.0F)){
   for(int i=0;i<samples.Count;i++){var p=samples[i];double left=i==0?from:(samples[i-1].Time+p.Time)/2.0;double right=i==samples.Count-1?to:(p.Time+samples[i+1].Time)/2.0;float a=x(left),b=x(right);
    if(!p.Good){g.FillRectangle(red,a,r.Top,Math.Max(1,b-a),r.Height);continue;}
    float yy=yval(p.Rtt);g.FillRectangle(green,a,yy,Math.Max(1,b-a),Math.Max(1,r.Bottom-yy));g.DrawLine(curve,a,yy,b,yy);
    if(i>0&&samples[i-1].Good)g.DrawLine(curve,a,yval(samples[i-1].Rtt),a,yy);
   }
  }
  using(var border=new Pen(Color.FromArgb(150,170,190),2))g.DrawRectangle(border,r.X,r.Y,r.Width,r.Height);
  for(int i=0;i<=4;i++){double t=from+span*i/4;string label=samples[samples.Count-1].Wall.AddMilliseconds(t-samples[samples.Count-1].Time).ToString("HH:mm:ss");SizeF z=g.MeasureString(label,Font);float xx=r.Left+r.Width*i/4;g.DrawString(label,Font,Brushes.Silver,Math.Max(0,xx-z.Width/2),r.Bottom+7);}
 }
}
public sealed class SoundQueue:IDisposable {
 readonly object gate=new object();readonly Queue<int> queue=new Queue<int>();readonly HashSet<int> scheduled=new HashSet<int>(); bool working,disposed; int generation;SoundPlayer current;
 public void Enqueue(int mode){lock(gate){if(disposed||scheduled.Contains(mode))return;scheduled.Add(mode);queue.Enqueue(mode);if(working)return;working=true;Task.Run((Action)Run);}}
 public bool Contains(int mode){lock(gate){return scheduled.Contains(mode);}}
 public void Clear(){lock(gate){generation++;queue.Clear();scheduled.Clear();if(current!=null)try{current.Stop();}catch{}}}
 void Run(){while(true){int mode,stamp;lock(gate){if(disposed||queue.Count==0){working=false;return;}mode=queue.Dequeue();stamp=generation;}
   try{using(var stream=Wave(mode))using(var p=new SoundPlayer(stream)){p.Load();lock(gate){if(disposed||stamp!=generation)continue;current=p;p.Play();}int duration=(int)((stream.Length-44)/44.1)+30;for(int elapsed=0;elapsed<duration;elapsed+=25){System.Threading.Thread.Sleep(25);lock(gate){if(disposed||stamp!=generation)break;}}lock(gate){p.Stop();if(current==p)current=null;}}}catch{lock(gate){current=null;}}
   lock(gate){if(stamp==generation)scheduled.Remove(mode);}
  }}
 public static MemoryStream Wave(int mode){
  // 1 short, 2 two long, 3 down, 4 double down, 5 up, 6 double up.
  const int rate=22050;int milliseconds=mode==1?180:mode==2?1240:2000;int count=milliseconds*rate/1000;
  var stream=new MemoryStream(44+count*2);var w=new BinaryWriter(stream);w.Write(System.Text.Encoding.ASCII.GetBytes("RIFF"));w.Write(36+count*2);w.Write(System.Text.Encoding.ASCII.GetBytes("WAVEfmt "));w.Write(16);w.Write((short)1);w.Write((short)1);w.Write(rate);w.Write(rate*2);w.Write((short)2);w.Write((short)16);w.Write(System.Text.Encoding.ASCII.GetBytes("data"));w.Write(count*2);
  double[] notes={392,440,493.88,523.25,587.33,659.25,698.46,783.99,880,987.77};
  for(int i=0;i<count;i++){double ms=i*1000.0/rate;bool tone;double freq=587.33,local,length;
   if(mode==1){local=ms;length=120;tone=local<length;}
   else if(mode==2){local=ms%620;length=500;tone=local<length;}
   else{int noteDuration=mode==4||mode==6?100:200;int note=(int)(ms/noteDuration)%10;bool up=mode==5||mode==6;freq=notes[up?note:9-note];local=ms%noteDuration;length=noteDuration*0.8;tone=local<length;}
   double envelope=tone?0.5-0.5*Math.Cos(Math.PI*Math.Min(1,Math.Min(local,length-local)/25.0)):0;double value=tone?Math.Sin(2*Math.PI*freq*local/1000.0)*0.16*envelope:0;w.Write((short)(value*short.MaxValue));
  }w.Flush();stream.Position=0;return stream;
 }
 public void Dispose(){lock(gate){disposed=true;}Clear();}
}
}
