﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
namespace NetworkLight {
public sealed class MailProfile {
 public bool Enabled=false, OnDown=true, OnUp=true, StartTls=true, Authenticate=true;
 public string Server="", User="", Secret="", From="", Recipients="";
 public int Port=587, TimeoutSeconds=20;
 public string DownTemplate="Потеряна связь с узлом {Узел}.\r\nАдрес: {Адрес}, метод: {Метод}, порт: {Порт}.\r\nНачало потери связи: {Потеря}.";
 public string UpTemplate="Связь с узлом {Узел} восстановлена.\r\nВремя восстановления: {Восстановление}.\r\nДлительность простоя: {Простой}.";
 public MailProfile Clone(){return (MailProfile)MemberwiseClone();}
 public static string Protect(string value){return string.IsNullOrEmpty(value)?"":Convert.ToBase64String(ProtectedData.Protect(Encoding.UTF8.GetBytes(value),null,DataProtectionScope.CurrentUser));}
 public string Password(){return string.IsNullOrEmpty(Secret)?"":Encoding.UTF8.GetString(ProtectedData.Unprotect(Convert.FromBase64String(Secret),null,DataProtectionScope.CurrentUser));}
 public static List<string> Addresses(string value){var parts=(value??"").Split(new[]{';',',','\r','\n'},StringSplitOptions.RemoveEmptyEntries);var result=new List<string>();foreach(string part in parts){var address=new MailAddress(part.Trim());result.Add(address.Address);}return result.Distinct(StringComparer.OrdinalIgnoreCase).ToList();}
 public string Validate(bool force){if(!Enabled&&!force)return null;try{
  if(string.IsNullOrWhiteSpace(Server)||Server.IndexOfAny(new[]{'\r','\n','/','\\',' '})>=0)return "Укажите имя SMTP-сервера без протокола и пробелов.";
  if(Port<1||Port>65535||TimeoutSeconds<5||TimeoutSeconds>120)return "Проверьте порт и тайм-аут SMTP (5–120 с).";
  if(Port==465)return "SMTP SSL/TLS на порту 465 не поддерживается. Используйте STARTTLS (обычно порт 587) или внутренний SMTP relay.";
  if(Authenticate&&!StartTls)return "Для передачи логина и пароля включите STARTTLS.";
  if(Authenticate&&(string.IsNullOrWhiteSpace(User)||string.IsNullOrEmpty(Secret)))return "Укажите SMTP-логин и пароль (или пароль приложения).";
  if(Authenticate)Password();
  new MailAddress(From);if(Addresses(Recipients).Count==0)return "Укажите хотя бы одного получателя.";
  if((DownTemplate??"").Length>4000||(UpTemplate??"").Length>4000)return "Шаблон не должен превышать 4000 символов.";
  return null;
 }catch(CryptographicException){return "Сохранённый пароль недоступен этому пользователю Windows. Введите его заново.";}catch{return "Проверьте адрес отправителя, получателей и сохранённый пароль.";}}
}
public sealed class MailJob {
 public string Id=Guid.NewGuid().ToString("N"), NodeId="", Subject="", Body="";
 public MailProfile Profile=new MailProfile();public DateTime CreatedUtc=DateTime.UtcNow, NextUtc=DateTime.UtcNow;public int Attempts;
}
public static class MailContent {
 public static string Name(Target t){return string.IsNullOrWhiteSpace(t.Comment)?t.Host:t.Comment.Trim();}
 public static string Stamp(DateTime utc){return utc.ToLocalTime().ToString("dd.MM.yyyy HH:mm:ss zzz",CultureInfo.InvariantCulture);}
 public static string Duration(TimeSpan duration){if(duration<TimeSpan.Zero)duration=TimeSpan.Zero;return string.Format(CultureInfo.InvariantCulture,"{0} д {1:00}:{2:00}:{3:00}",(int)duration.TotalDays,duration.Hours,duration.Minutes,duration.Seconds);}
 public static string Expand(string template,Target t,DateTime down,DateTime? up,TimeSpan duration){
  // One pass: values supplied by the user cannot themselves expand as tokens.
  var tokens=new Dictionary<string,string>{{"Узел",Name(t)},{"Адрес",t.Host},{"Порт",t.Port.ToString()},{"Метод",t.Mode},{"Потеря",Stamp(down)},{"Восстановление",up.HasValue?Stamp(up.Value):"—"},{"Простой",Duration(duration)}};
  return System.Text.RegularExpressions.Regex.Replace(template??"",@"\{(Узел|Адрес|Порт|Метод|Потеря|Восстановление|Простой)\}",m=>tokens[m.Groups[1].Value]);
 }
 public static MailJob Build(Target t,DateTime down,DateTime at,bool restored,TimeSpan duration){var profile=t.Mail.Clone();string name=Name(t);string subject=(restored?"Monitor is UP: ":"Monitor is DOWN: ")+name;subject=subject.Replace("\r"," ").Replace("\n"," ");if(subject.Length>800)subject=subject.Substring(0,800);
  string body=Expand(restored?profile.UpTemplate:profile.DownTemplate,t,down,restored?(DateTime?)at:null,duration);
  body+="\r\n\r\n— Данные события NetworkLight —\r\nУзел: "+name+"\r\nАдрес: "+t.Host+"\r\nМетод: "+t.Mode+"; порт: "+t.Port+"\r\nНачало потери связи: "+Stamp(down);
  body+=restored?"\r\nВосстановление связи: "+Stamp(at)+"\r\nДлительность простоя: "+Duration(duration):"\r\nПадение подтверждено: "+Stamp(at);
  body+="\r\nВремя указано по часовому поясу компьютера мониторинга. Доставка могла быть отложена.";
  return new MailJob{NodeId=t.MailId,Profile=profile,Subject=subject,Body=body,CreatedUtc=at,NextUtc=DateTime.UtcNow};
 }
}
public static class MailTransport {
 static MailTransport(){ServicePointManager.SecurityProtocol=SecurityProtocolType.Tls12;}
 public static void Send(MailJob job){var p=job.Profile;string error=p.Validate(true);if(error!=null)throw new InvalidOperationException(error);
  using(var message=new MailMessage()){message.From=new MailAddress(p.From);foreach(string to in MailProfile.Addresses(p.Recipients))message.To.Add(to);message.Subject=job.Subject;message.SubjectEncoding=Encoding.UTF8;message.Body=job.Body;message.BodyEncoding=Encoding.UTF8;message.IsBodyHtml=false;message.Headers.Add("Message-ID","<"+job.Id+"@networklight.local>");
   using(var client=new SmtpClient(p.Server,p.Port)){client.DeliveryMethod=SmtpDeliveryMethod.Network;client.EnableSsl=p.StartTls;client.Timeout=p.TimeoutSeconds*1000;client.UseDefaultCredentials=false;if(p.Authenticate)client.Credentials=new NetworkCredential(p.User,p.Password());client.Send(message);}
  }
 }
}
// Bounded durable outbox; a single background worker performs disk and SMTP I/O.
public sealed class MailQueue:IDisposable {
 readonly object gate=new object();List<MailJob> jobs=new List<MailJob>();System.Threading.Timer timer;string path,status="Писем в очереди нет";bool working,stopped,dirty;
 public string Status {get{lock(gate)return "В очереди: "+jobs.Count+". "+status;}}
 public void Start(string file,IEnumerable<string> enabledNodes){lock(gate){var enabledIds=new HashSet<string>(enabledNodes);path=file;try{if(File.Exists(path)){byte[] data=ProtectedData.Unprotect(File.ReadAllBytes(path),null,DataProtectionScope.CurrentUser);using(var stream=new MemoryStream(data))jobs=(List<MailJob>)new XmlSerializer(typeof(List<MailJob>)).Deserialize(stream);if(jobs==null||jobs.Count>500)throw new InvalidDataException();status="Очередь восстановлена";}}catch{jobs=new List<MailJob>();status="Не удалось прочитать очередь; файл сохранён для диагностики";try{File.Move(path,path+".unreadable-"+DateTime.Now.ToString("yyyyMMddHHmmss"));}catch{path=null;status="Очередь недоступна: проверьте доступ к файлу mail-queue.dat";}}
   if(jobs.RemoveAll(j=>!enabledIds.Contains(j.NodeId))>0)dirty=true;timer=new System.Threading.Timer(s=>Kick(),null,2000,2000);
  }}
 public bool Enqueue(MailJob job){lock(gate){if(stopped||string.IsNullOrEmpty(path)){status="Отправка недоступна: очередь не открыта";return false;}if(jobs.Count>=500){status="Очередь заполнена (500 писем): новое событие не добавлено";return false;}jobs.Add(job);dirty=true;}Kick();return true;}
 public void Cancel(string nodeId){lock(gate){jobs.RemoveAll(j=>j.NodeId==nodeId);dirty=true;}Kick();}
 void SaveLocked(){if(!dirty||string.IsNullOrEmpty(path))return;Directory.CreateDirectory(Path.GetDirectoryName(path));byte[] raw;using(var stream=new MemoryStream()){new XmlSerializer(typeof(List<MailJob>)).Serialize(stream,jobs);raw=stream.ToArray();}byte[] data=ProtectedData.Protect(raw,null,DataProtectionScope.CurrentUser);string temp=path+".tmp";File.WriteAllBytes(temp,data);if(File.Exists(path))File.Replace(temp,path,path+".bak");else File.Move(temp,path);dirty=false;}
 void Kick(){lock(gate){if(stopped||working||string.IsNullOrEmpty(path))return;working=true;}Task.Run((Action)Work);}
 void Work(){try{while(true){MailJob job=null;lock(gate){if(stopped)return;var now=DateTime.UtcNow;if(jobs.RemoveAll(j=>now-j.CreatedUtc>TimeSpan.FromHours(72))>0){dirty=true;status="Истёк срок доставки части писем (72 часа)";}SaveLocked();var seen=new HashSet<string>();foreach(var candidate in jobs){if(!seen.Add(candidate.NodeId))continue;if(candidate.NextUtc<=now){job=candidate;break;}}if(job==null)return;}
    string error=null;try{MailTransport.Send(job);}catch(Exception ex){var smtp=ex as SmtpException;error=smtp==null?ex.GetType().Name:smtp.StatusCode.ToString();}
    lock(gate){if(jobs.Contains(job)){if(error==null){jobs.Remove(job);status="Отправлено: "+DateTime.Now.ToString("HH:mm:ss");}else{job.Attempts++;job.NextUtc=DateTime.UtcNow.AddSeconds(Math.Min(900,60*Math.Pow(2,Math.Min(4,job.Attempts-1))));status="Ошибка SMTP: "+error+". Повтор после "+job.NextUtc.ToLocalTime().ToString("HH:mm:ss");}dirty=true;}SaveLocked();}
   }}catch{lock(gate)status="Ошибка сохранения очереди. Проверьте доступ к папке приложения.";}finally{lock(gate)working=false;}}
 public void Dispose(){lock(gate){stopped=true;if(timer!=null)timer.Dispose();try{SaveLocked();}catch{}}}
}
public sealed class MailTransition {public bool Restored;public DateTime DownUtc, EventUtc;public TimeSpan Duration;}
public static class MailIncident {
 public static void Reset(Node n){n.Target.MailDownUtc=null;n.FirstFailureUtc=null;n.MailDownTick=-1;}
 public static MailTransition Observe(Node n,bool success,DateTime at,long tick){
  if(!success&&!n.FirstFailureUtc.HasValue)n.FirstFailureUtc=at;
  if(n.Alarm.Offline&&!n.Target.MailDownUtc.HasValue){n.Target.MailDownUtc=n.FirstFailureUtc??at;n.MailDownTick=Math.Max(0,tick-(long)(at-n.Target.MailDownUtc.Value).TotalMilliseconds);return new MailTransition{DownUtc=n.Target.MailDownUtc.Value,EventUtc=at};}
  if(success){if(n.Target.MailDownUtc.HasValue){var result=new MailTransition{Restored=true,DownUtc=n.Target.MailDownUtc.Value,EventUtc=at,Duration=n.MailDownTick>=0?TimeSpan.FromMilliseconds(Math.Max(0,tick-n.MailDownTick)):at-n.Target.MailDownUtc.Value};Reset(n);return result;}n.FirstFailureUtc=null;}
  return null;
 }
}
public partial class MainForm {
 void ResetMailIncident(Node n){MailIncident.Reset(n);}
 void ObserveMail(Node n,bool success,DateTime at){var change=MailIncident.Observe(n,success,at,clock.ElapsedMilliseconds);if(change==null)return;var p=n.Target.Mail;if(p!=null&&p.Enabled&&(change.Restored?p.OnUp:p.OnDown))mailQueue.Enqueue(MailContent.Build(n.Target,change.DownUtc,change.EventUtc,change.Restored,change.Duration));Save();}
 void ToggleMail(Node n){bool wasEnabled=n.Target.Mail!=null&&n.Target.Mail.Enabled;var p=n.Target.Mail==null?(settings.MailDefaults??new MailProfile()).Clone():n.Target.Mail.Clone();p.Enabled=!wasEnabled;string error=p.Validate(false);if(error!=null){System.Windows.Forms.MessageBox.Show(error+"\nОткройте Редактировать узел → Уведомление.");return;}n.Target.Mail=p;if(!p.Enabled)mailQueue.Cancel(n.Target.MailId);RefreshRow(n);Save();}
}
}
