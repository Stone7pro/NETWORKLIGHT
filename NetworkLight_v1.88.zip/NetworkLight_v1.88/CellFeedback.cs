﻿using System;
using System.Drawing;
using System.Windows.Forms;
namespace NetworkLight {
public sealed class MetricTrend {
 bool hasValue;double previous;public long Until;public int Direction;
 public void Observe(double value,long now){if(hasValue){int direction=value.CompareTo(previous);if(direction!=0){Direction=direction;Until=now+2000;}}previous=value;hasValue=true;}
 public int Active(long now){return now<Until?Direction:0;}
 public void Reset(){hasValue=false;previous=0;Until=0;Direction=0;}
}
public partial class MainForm {
 static bool TextEditable(int col){return col==10||col==0||col==2||col==3||col==13;}
 static bool EditableValue(int col){return TextEditable(col)||col==1||col==11||col==14;}
 static bool ValidHost(string host){return host.Length>0&&host.Length<=253&&Uri.CheckHostName(host)!=UriHostNameType.Unknown;}
 void EditHostCell(){if(grid.CurrentRow==null)return;if(!grid.EndEdit())return;grid.Columns[0].Visible=true;grid.CurrentCell=grid.CurrentRow.Cells[0];grid.BeginEdit(true);}
 void InitEditableHints(){grid.ShowCellToolTips=false;var tip=new ToolTip(menus){AutoPopDelay=3000,InitialDelay=400,ReshowDelay=200};
  grid.CellMouseEnter+=(s,e)=>{tip.Hide(grid);if(e.RowIndex<0||e.ColumnIndex<0)return;string text=EditableValue(e.ColumnIndex)?"Для изменения щелкните дважды ЛКМ":grid.Rows[e.RowIndex].Cells[e.ColumnIndex].ToolTipText;if(string.IsNullOrEmpty(text))return;var r=grid.GetCellDisplayRectangle(e.ColumnIndex,e.RowIndex,true);tip.Show(text,grid,r.Left+Math.Min(20,r.Width),r.Bottom,3000);};
  grid.CellMouseLeave+=(s,e)=>tip.Hide(grid);grid.CellBeginEdit+=(s,e)=>tip.Hide(grid);grid.Scroll+=(s,e)=>tip.Hide(grid);
  grid.EditingControlShowing+=(s,e)=>{e.Control.BackColor=Color.FromArgb(74,81,91);e.Control.ForeColor=Color.White;var text=e.Control as TextBox;if(text!=null){text.TextAlign=HorizontalAlignment.Center;text.Multiline=grid.CurrentCell.ColumnIndex==13;text.AcceptsReturn=text.Multiline;text.MaxLength=grid.CurrentCell.ColumnIndex==13?500:grid.CurrentCell.ColumnIndex==0?253:20;}};
 }
 void PaintEditable(DataGridViewCellPaintingEventArgs e){var saved=e.Graphics.Save();e.Graphics.SetClip(e.ClipBounds,System.Drawing.Drawing2D.CombineMode.Intersect);try{e.Paint(e.ClipBounds,DataGridViewPaintParts.Background|DataGridViewPaintParts.Border);var r=e.CellBounds;r.Inflate(-5,-5);if(r.Width>2&&r.Height>2){bool selected=(e.State&DataGridViewElementStates.Selected)!=0;using(var fill=new SolidBrush(selected?Color.FromArgb(85,98,114):Color.FromArgb(65,72,82)))e.Graphics.FillRectangle(fill,r);using(var border=new Pen(selected?Color.FromArgb(162,202,235):Color.FromArgb(124,135,149),2))e.Graphics.DrawRectangle(border,r);r.Inflate(-4,-2);TextRenderer.DrawText(e.Graphics,Convert.ToString(e.FormattedValue),e.CellStyle.Font,r,Color.White,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis|(e.ColumnIndex==13?TextFormatFlags.WordBreak:0));}e.Handled=true;}finally{e.Graphics.Restore(saved);}}
 static readonly Color WarningCell=Color.FromArgb(228,190,69),GoodCell=Color.FromArgb(100,185,121),BadCell=Color.FromArgb(194,62,62);
 static void Tint(DataGridViewCell cell,Color color){var style=cell.Style;Color fg=color.IsEmpty?Color.Empty:color==BadCell?Color.White:Color.FromArgb(19,27,35);if(style.BackColor!=color)style.BackColor=color;if(style.SelectionBackColor!=color)style.SelectionBackColor=color;if(style.ForeColor!=fg)style.ForeColor=fg;if(style.SelectionForeColor!=fg)style.SelectionForeColor=fg;}
 static Color AverageTint(long sum,long replies,long min,long max){if(replies<=0)return Color.Empty;return (decimal)sum/replies>(decimal)min+((decimal)max-min)/2?WarningCell:GoodCell;}
 void UpdateCellColors(Node n,long now){if(n.Row==null||n.Row.DataGridView==null)return;Color loss=Color.Empty;if(n.Target.Running){if(n.Alarm.Offline){if(n.Alarm.Bad>0)loss=BadCell;}else if(NodeState(n,now)==2)loss=WarningCell;}Tint(n.Row.Cells[6],loss);
  int max=n.MaximumTrend.Active(now);
  Tint(n.Row.Cells[8],AverageTint(n.Sum,n.Replies,n.Min,n.Max));Tint(n.Row.Cells[9],max>0?WarningCell:max<0?GoodCell:Color.Empty);
 }
}
}
