﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace NetworkLight {
[Flags] public enum AlarmEvent { None=0, FirstLoss=1, Intermittent=2, Down=4, Recovery=8 }
public sealed class AlarmCycle {
 public int Position, Good, Bad, ConsecutiveLosses;
 public bool Offline, LastSuccess, HasSample, HasEverSucceeded;
 bool successAfterLoss, mixedNotified;
 public int Status {get{return Offline?3:!HasSample?0:Bad>0?2:Good>0?1:0;}}
 public void Reset(){Position=Good=Bad=ConsecutiveLosses=0;Offline=LastSuccess=HasSample=HasEverSucceeded=successAfterLoss=mixedNotified=false;}
 public void ConfirmOffline(){Offline=true;LastSuccess=false;HasSample=true;}
 public void ResetCycle(){Position=Good=Bad=0;successAfterLoss=mixedNotified=false;}
 public AlarmEvent Feed(bool success,int polls,int threshold=6){
  bool newCycle=Position==0||Position>=Math.Max(1,polls);if(newCycle)ResetCycle();
  Position++;HasSample=true;LastSuccess=success;AlarmEvent result=AlarmEvent.None;
  if(success){Good++;HasEverSucceeded=true;ConsecutiveLosses=0;if(Bad>0)successAfterLoss=true;if(Offline){Offline=false;result=AlarmEvent.Recovery;}}
  else{Bad++;ConsecutiveLosses=Math.Min(10000,ConsecutiveLosses+1);if(ConsecutiveLosses>=Math.Max(1,threshold)){if(!Offline)result=AlarmEvent.Down;Offline=true;}
   else if(!Offline){if(Bad==1)result=AlarmEvent.FirstLoss;else if(successAfterLoss&&!mixedNotified){mixedNotified=true;result=AlarmEvent.Intermittent;}}}
  return result;
 }
 public static int Tray(IEnumerable<int> source){int g=0,y=0,r=0,u=0;foreach(int state in source){if(state==1)g++;else if(state==2)y++;else if(state==3)r++;else u++;}if(g+y+r==0||u>0)return 0;if(r>0&&g+y+u==0)return 6;if(g==0&&y>0)return 5;if(r>0&&y>0)return 4;if(r>0)return 3;if(y>0)return 2;return u>0?0:1;}
}
// Fixed capacity ring: appending a probe never shifts the preceding results.
public sealed class SampleBuffer {
 Sample[] data=new Sample[0];int start,count;
 public int Count{get{return count;}}
 public void SetCapacity(int capacity){capacity=Math.Max(1,Math.Min(5000,capacity));if(data.Length==capacity)return;var previous=Snapshot();data=new Sample[capacity];start=count=0;foreach(var s in previous.Skip(Math.Max(0,previous.Count-capacity)))Add(s);}
 public void Add(Sample s){if(data.Length==0)SetCapacity(200);if(count<data.Length){data[(start+count)%data.Length]=s;count++;}else{data[start]=s;start=(start+1)%data.Length;}}
 public List<Sample> Snapshot(){var result=new List<Sample>(count);for(int i=0;i<count;i++)result.Add(data[(start+i)%data.Length]);return result;}
 public void Clear(){Array.Clear(data,0,data.Length);count=start=0;}
}
}
namespace NetworkLight {
public sealed class NotificationPlan {public bool ClearQueue;public readonly List<int> Sounds=new List<int>();}
public sealed class AlarmNotifier {
 bool previousAllDead,recoveryArmed;
 public void Reset(){previousAllDead=recoveryArmed=false;}
 public void NoteOutage(){recoveryArmed=true;}
 public void TopologyChanged(){recoveryArmed=false;}
 public NotificationPlan Evaluate(IEnumerable<Node> source,Settings settings){var plan=new NotificationPlan();var running=source.Where(n=>n.Target.Running).ToList();if(running.Count==0){Reset();return plan;}
  bool allDead=running.All(n=>n.Alarm.Offline);bool anyDead=running.Any(n=>n.Alarm.Offline);bool allUp=running.All(n=>n.Alarm.HasSample&&n.Alarm.LastSuccess&&!n.Alarm.Offline);
  if(anyDead)recoveryArmed=true;bool allRecovered=recoveryArmed&&allUp;if(allRecovered)recoveryArmed=false;
  AlarmEvent events=AlarmEvent.None;foreach(var n in running){if(!settings.SoundMuted&&n.Target.SoundEnabled){AlarmEvent pending=n.Pending;if(!n.Alarm.Offline)pending&=~AlarmEvent.Down;else pending&=~AlarmEvent.Recovery;events|=pending;}n.Pending=AlarmEvent.None;}
  if(allDead){previousAllDead=true;return plan;}previousAllDead=false;
  // Recovery notifications belong exclusively to RecoveryBatch.

  if((events&AlarmEvent.Intermittent)!=0&&settings.IntermittentSound)plan.Sounds.Add(2);
  if((events&AlarmEvent.FirstLoss)!=0&&settings.Sound1)plan.Sounds.Add(1);
  return plan;
 }
}
}
