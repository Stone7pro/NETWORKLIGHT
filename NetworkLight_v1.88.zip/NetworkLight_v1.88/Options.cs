﻿using System;
using System.Drawing;
using System.Windows.Forms;
namespace NetworkLight {
public partial class MainForm {
 void SettingsDialog(){using(var f=new Form{Text="Настройки NetworkLight 1.88",ClientSize=new Size(740,590),MinimumSize=new Size(690,580),StartPosition=FormStartPosition.CenterParent,Font=Font,BackColor=panel,ForeColor=Color.White}){
  var tabs=new TabControl{Dock=DockStyle.Fill};var general=new TabPage("Основные"){BackColor=panel,ForeColor=Color.White,Padding=new Padding(16)};var alarms=new TabPage("Тревога"){BackColor=panel,ForeColor=Color.White,Padding=new Padding(16)};tabs.TabPages.Add(general);tabs.TabPages.Add(alarms);var mailTab=new TabPage("Уведомления"){BackColor=panel,ForeColor=Color.White};var mailEditor=new MailEditor(settings.MailDefaults,()=>mailQueue.Status);mailTab.Controls.Add(mailEditor);var defaultsNote=new Label{Dock=DockStyle.Top,Height=48,Padding=new Padding(10),Text="Настройки по умолчанию для новых узлов. Параметры существующих узлов меняются в их редакторе."};mailTab.Controls.Add(defaultsNote);tabs.TabPages.Add(mailTab);
  var g=OptionsTable();general.Controls.Add(g);var a=OptionsTable();alarms.Controls.Add(a);
  var auto=new CheckBox{Checked=AutoStart(),Text="Включён",TextAlign=ContentAlignment.MiddleCenter,AutoSize=false};AddOption(g,"Автозапуск текущего пользователя",auto);
  var pin=OptionCheck(settings.PinWindow);AddOption(g,"Закрепить окно на экране (Win+D)",pin);var pinTip=new ToolTip{AutoPopDelay=6000};pinTip.SetToolTip(pin,PinHint);f.Disposed+=(s,e)=>pinTip.Dispose();
  var timeout=Number(100,30000,settings.Timeout);timeout.Increment=100;AddOption(g,"Тайм-аут запроса по умолчанию, мс",timeout);
  var points=Number(1,5000,settings.DefaultGraphCount);AddOption(g,"Результатов на графике новых узлов",points);
  int newKey=settings.HotKey,newMods=settings.Modifiers;var key=new TextBox{ReadOnly=true,TextAlign=HorizontalAlignment.Center};Action showKey=()=>key.Text=((newMods&2)!=0?"Ctrl + ":"")+((newMods&1)!=0?"Alt + ":"")+((newMods&4)!=0?"Shift + ":"")+((Keys)newKey).ToString();showKey();
  key.KeyDown+=(s,e)=>{e.SuppressKeyPress=true;if(e.KeyCode==Keys.ControlKey||e.KeyCode==Keys.Menu||e.KeyCode==Keys.ShiftKey)return;if(!e.Control&&!e.Alt){MessageBox.Show("Используйте Ctrl или Alt вместе с клавишей.");return;}newKey=(int)e.KeyCode;newMods=(e.Control?2:0)|(e.Alt?1:0)|(e.Shift?4:0);showKey();};AddOption(g,"Старт / стоп всех — нажмите сочетание",key);
  int nodeKey=settings.NodeHotKey,nodeMods=settings.NodeModifiers;var nodeShortcut=new TextBox{ReadOnly=true,TextAlign=HorizontalAlignment.Center};Action showNodeKey=()=>nodeShortcut.Text=((nodeMods&2)!=0?"Ctrl + ":"")+((nodeMods&1)!=0?"Alt + ":"")+((nodeMods&4)!=0?"Shift + ":"")+((Keys)nodeKey).ToString();showNodeKey();
  nodeShortcut.KeyDown+=(s,e)=>{e.SuppressKeyPress=true;if(e.KeyCode==Keys.ControlKey||e.KeyCode==Keys.Menu||e.KeyCode==Keys.ShiftKey)return;if(!e.Control&&!e.Alt){MessageBox.Show("Используйте Ctrl или Alt вместе с клавишей.");return;}nodeKey=(int)e.KeyCode;nodeMods=(e.Control?2:0)|(e.Alt?1:0)|(e.Shift?4:0);showNodeKey();};AddOption(g,"Старт / стоп текущего узла (в окне приложения)",nodeShortcut);
  var polls=Number(1,10000,settings.AlarmPolls);AddOption(a,"Интервал тревоги для новых узлов, кол-во опросов",polls);
  var alarmTip=new ToolTip{AutoPopDelay=15000};alarmTip.SetToolTip(polls,AlarmHint);alarmTip.SetToolTip(a.GetControlFromPosition(0,0),AlarmHint);f.Disposed+=(s,e)=>alarmTip.Dispose();
  var threshold=Number(1,10000,settings.FailureThreshold);AddOption(a,"Считать канал упавшим после потерь подряд",threshold);
  var shortLoss=OptionCheck(settings.Sound1);AddOption(a,"Первая потеря — короткий сигнал",shortLoss);
  var mixed=OptionCheck(settings.IntermittentSound);AddOption(a,"Повтор потерь после ответов — два длинных",mixed);
  var down=OptionCheck(settings.Sound2);AddOption(a,"Узел упал — нисходящая трель, 2 с",down);
  var allDown=OptionCheck(settings.Sound3);AddOption(a,"Все упали — двойная нисходящая трель, 2 с",allDown);
  var up=OptionCheck(settings.RecoverySound);AddOption(a,"Узел восстановился — восходящая трель, 2 с",up);
  var allUp=OptionCheck(settings.AllRecoverySound);AddOption(a,"Все восстановились — двойная восходящая, 2 с",allUp);
  var testModes=new ComboBox{DropDownStyle=ComboBoxStyle.DropDownList,DrawMode=DrawMode.OwnerDrawFixed};testModes.Items.AddRange(new object[]{"Короткий","Два длинных","Узел упал","Все упали","Узел поднялся","Все поднялись"});testModes.SelectedIndex=0;testModes.DrawItem+=(s,e)=>{e.DrawBackground();if(e.Index>=0)TextRenderer.DrawText(e.Graphics,testModes.Items[e.Index].ToString(),testModes.Font,e.Bounds,e.ForeColor,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter);e.DrawFocusRectangle();};AddOption(a,"Проверить выбранный сигнал",testModes);var test=Button("Прослушать",()=>sounds.Enqueue(testModes.SelectedIndex+1));AddOption(a,"Тест воспроизводится даже при общей паузе",test);
  var bottom=new FlowLayoutPanel{Dock=DockStyle.Bottom,Height=58,FlowDirection=FlowDirection.RightToLeft,Padding=new Padding(12)};
  var save=Button("Сохранить",()=>{MailProfile mailDefaults;try{mailDefaults=mailEditor.Read(true);}catch(Exception ex){tabs.SelectedTab=mailTab;MessageBox.Show(ex.Message,"Уведомления");return;}if(newKey==nodeKey&&newMods==nodeMods){MessageBox.Show("Выберите разные сочетания для узла и всех каналов.");return;}
   UnregisterHotKey(Handle,1);UnregisterHotKey(Handle,2);
   bool allOK=RegisterHotKey(Handle,1,(uint)newMods|0x4000,(uint)newKey);bool nodeOK=RegisterHotKey(Handle,2,(uint)nodeMods|0x4000,(uint)nodeKey);
   if(!allOK||!nodeOK){RestoreHotKeys();MessageBox.Show("Одно из сочетаний занято. Выберите другое.");return;}
   try{if(auto.Checked!=AutoStart())SetAuto(auto.Checked);}catch(Exception ex){RestoreHotKeys();MessageBox.Show("Автозапуск не изменён: "+ex.Message);return;}
   settings.MailDefaults=mailDefaults;hotRegistered=nodeHotRegistered=true;settings.NodeHotKey=nodeKey;settings.NodeModifiers=nodeMods;
   if(settings.FailureThreshold!=(int)threshold.Value){ResetAggregate();foreach(var n in nodes)n.Pending=AlarmEvent.None;}settings.FailureThreshold=(int)threshold.Value;settings.HotKey=newKey;settings.Modifiers=newMods;settings.Timeout=(int)timeout.Value;settings.DefaultGraphCount=(int)points.Value;settings.AlarmPolls=(int)polls.Value;settings.Sound1=shortLoss.Checked;settings.IntermittentSound=mixed.Checked;settings.Sound2=down.Checked;settings.Sound3=allDown.Checked;settings.RecoverySound=up.Checked;settings.AllRecoverySound=allUp.Checked;sounds.Clear();SetPinned(pin.Checked);SaveNow();f.Close();});bottom.Controls.Add(save);bottom.Controls.Add(Button("Отмена",()=>f.Close()));f.Controls.Add(tabs);f.Controls.Add(bottom);f.ShowDialog(this);
 }}
 void RestoreHotKeys(){UnregisterHotKey(Handle,1);UnregisterHotKey(Handle,2);hotRegistered=RegisterHotKey(Handle,1,(uint)settings.Modifiers|0x4000,(uint)settings.HotKey);nodeHotRegistered=RegisterHotKey(Handle,2,(uint)settings.NodeModifiers|0x4000,(uint)settings.NodeHotKey);}
 static CheckBox OptionCheck(bool value){return new CheckBox{Checked=value,Text="Включён",TextAlign=ContentAlignment.MiddleCenter,AutoSize=false};}
 static TableLayoutPanel OptionsTable(){var t=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2,AutoScroll=true};t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));t.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,190));return t;}
 static void AddOption(TableLayoutPanel table,string caption,Control value){int row=table.RowCount++;table.RowStyles.Add(new RowStyle(SizeType.Absolute,43));var label=new Label{Text=caption,Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleLeft,AutoEllipsis=true};value.Anchor=AnchorStyles.Left|AnchorStyles.Right;value.Margin=new Padding(6,7,6,7);table.Controls.Add(label,0,row);table.Controls.Add(value,1,row);}
}
}
