﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
namespace NetworkLight {
public partial class MainForm {
 const string PinHint="Закрепить окно поверх остальных и сохранять его на экране при Win+D. Чтобы убрать окно в трей, нажмите крестик. Для обычного сворачивания снимите галочку.";
 readonly CheckBox pinCheck=new CheckBox();readonly System.Windows.Forms.Timer pinGuard=new System.Windows.Forms.Timer();bool pinVisibleExpected,pinRestoring,pinQueued;FormWindowState pinLastState=FormWindowState.Normal;
 bool PinActive{get{return settings!=null&&settings.PinWindow&&pinVisibleExpected&&!exiting;}}
 [DllImport("user32.dll")]static extern bool SetWindowPos(IntPtr h,IntPtr after,int x,int y,int width,int height,uint flags);
 [DllImport("user32.dll")]static extern bool IsIconic(IntPtr h);
 [DllImport("user32.dll")]static extern bool IsWindowVisible(IntPtr h);
 [DllImport("user32.dll")]static extern bool ShowWindow(IntPtr h,int command);
 [DllImport("user32.dll")]static extern IntPtr GetLastActivePopup(IntPtr h);
 void InitPin(ToolTip tip){pinCheck.Text="Закрепить";pinCheck.AutoSize=true;pinCheck.Checked=settings.PinWindow;pinCheck.CheckAlign=System.Drawing.ContentAlignment.MiddleLeft;pinCheck.TextAlign=System.Drawing.ContentAlignment.MiddleLeft;tip.SetToolTip(pinCheck,PinHint);pinCheck.CheckedChanged+=(s,e)=>SetPinned(pinCheck.Checked);pinGuard.Interval=200;pinGuard.Tick+=(s,e)=>KeepPinned();}
 void SetPinned(bool enabled){settings.PinWindow=enabled;if(pinCheck.Checked!=enabled)pinCheck.Checked=enabled;UpdatePinMode();Save();}
 void UpdatePinMode(){if(settings==null||IsDisposed)return;TopMost=settings.PinWindow;MinimizeBox=!settings.PinWindow;pinGuard.Enabled=PinActive;if(PinActive)KeepPinned();}
 void QueuePinRestore(){if(pinQueued||!IsHandleCreated)return;pinQueued=true;BeginInvoke((Action)(()=>{pinQueued=false;if(PinActive)KeepPinned();}));}
 void KeepPinned(){if(!PinActive||pinRestoring||IsDisposed||!IsHandleCreated)return;foreach(System.ComponentModel.IComponent component in menus.Components){var menu=component as ContextMenuStrip;if(menu!=null&&menu.Visible)return;}pinRestoring=true;try{
  // Win+D can lower the desktop over a topmost window without sending SC_MINIMIZE.
  // Reassert only our own window, without intercepting keys or activating it.
  if(IsIconic(Handle)){var savedState=pinLastState;ShowWindow(Handle,4);if(savedState==FormWindowState.Maximized)WindowState=FormWindowState.Maximized;}
  if(!IsWindowVisible(Handle))ShowWindow(Handle,8);
  SetWindowPos(Handle,new IntPtr(-1),0,0,0,0,0x0001|0x0002|0x0010|0x0040|0x0200);
  // Keep a settings/editor/message window above its pinned owner.
  IntPtr popup=GetLastActivePopup(Handle);if(popup!=Handle&&popup!=IntPtr.Zero&&IsWindowVisible(popup))SetWindowPos(popup,new IntPtr(-1),0,0,0,0,0x0001|0x0002|0x0010|0x0200);
 }finally{pinRestoring=false;}}
}
}
