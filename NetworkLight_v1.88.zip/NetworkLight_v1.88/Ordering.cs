﻿using System;
using System.Collections;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
namespace NetworkLight {public partial class MainForm {
 bool orderPending;long eventSequence;readonly Timer commentDelay=new Timer{Interval=2000};Node hoverNode;
 void InitPins(){var pin=new DataGridViewTextBoxColumn{Name="pin",HeaderText="📌",Width=45,MinimumWidth=40,ReadOnly=true,SortMode=DataGridViewColumnSortMode.NotSortable};grid.Columns.Add(pin);pin.DisplayIndex=grid.Columns[0].DisplayIndex;
 var hint=new ToolTip(menus){AutoPopDelay=5000};var note=new ToolTip(menus){AutoPopDelay=15000};pinCheck.CheckedChanged+=(s,e)=>{commentDelay.Stop();note.Hide(grid);};commentDelay.Tick+=(s,e)=>{commentDelay.Stop();if(!settings.PinWindow&&hoverNode!=null&&!string.IsNullOrWhiteSpace(hoverNode.Target.LongComment))note.Show(hoverNode.Target.LongComment,grid,grid.PointToClient(Cursor.Position)+new Size(12,20),15000);};
 grid.CellMouseEnter+=(s,e)=>{commentDelay.Stop();note.Hide(grid);hoverNode=e.RowIndex>=0?grid.Rows[e.RowIndex].Tag as Node:null;if(hoverNode==null)return;if(e.ColumnIndex==15)hint.Show(hoverNode.Target.PinOrder>0?"Открепить канал":"Закрепить канал вверху списка",grid,grid.PointToClient(Cursor.Position)+new Size(10,20),5000);else if(!settings.PinWindow)commentDelay.Start();};grid.CellMouseLeave+=(s,e)=>{hoverNode=null;commentDelay.Stop();note.Hide(grid);hint.Hide(grid);};grid.Scroll+=(s,e)=>{hoverNode=null;commentDelay.Stop();note.Hide(grid);};FormClosed+=(s,e)=>{commentDelay.Dispose();note.Dispose();};
 }
 void TogglePin(Node n){n.Target.PinOrder=n.Target.PinOrder>0?0:nodes.Select(x=>x.Target.PinOrder).DefaultIfEmpty().Max()+1;orderPending=true;ApplyEventOrder();Save();}
 void ClearPins(){foreach(var n in nodes)n.Target.PinOrder=0;orderPending=true;ApplyEventOrder();Save();}
 void Promote(Node n){n.EventOrder=++eventSequence;orderPending=true;}
 sealed class EventComparer:IComparer {public int Compare(object x,object y){var a=(Node)((DataGridViewRow)x).Tag;var b=(Node)((DataGridViewRow)y).Tag;if(a.Target.PinOrder>0||b.Target.PinOrder>0){if(a.Target.PinOrder==0)return 1;if(b.Target.PinOrder==0)return -1;return a.Target.PinOrder.CompareTo(b.Target.PinOrder);}int c=b.EventOrder.CompareTo(a.EventOrder);return c!=0?c:a.Target.Number.CompareTo(b.Target.Number);}}
 void ApplyEventOrder(){if(grid.IsCurrentCellInEditMode){orderPending=true;return;}orderPending=false;foreach(var n in nodes)n.Row.Cells[15].Value=n.Target.PinOrder>0?"📌":"○";grid.Sort(new EventComparer());nodes.Clear();nodes.AddRange(grid.Rows.Cast<DataGridViewRow>().Select(r=>(Node)r.Tag));foreach(DataGridViewColumn c in grid.Columns)c.HeaderCell.SortGlyphDirection=SortOrder.None;Save();}
}}
