﻿using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace NetworkLight {
public sealed class MailEditor:UserControl {
 readonly TableLayoutPanel table=new TableLayoutPanel();readonly CheckBox enabled=new CheckBox(),down=new CheckBox(),up=new CheckBox(),tls=new CheckBox(),auth=new CheckBox();readonly Button clearPassword=new Button();
 readonly TextBox server=new TextBox(),user=new TextBox(),password=new TextBox(),from=new TextBox(),recipients=new TextBox(),downBody=new TextBox(),upBody=new TextBox();readonly NumericUpDown port=new NumericUpDown(),timeout=new NumericUpDown();
 readonly Label status=new Label();readonly Button test=new Button();readonly System.Windows.Forms.Timer refresh=new System.Windows.Forms.Timer();string secret="";readonly Func<string> queueStatus;
 public MailEditor(MailProfile profile,Func<string> queue){queueStatus=queue;Dock=DockStyle.Fill;AutoScroll=true;BackColor=Color.FromArgb(34,44,58);ForeColor=Color.White;
  table.Dock=DockStyle.Top;table.AutoSize=true;table.ColumnCount=2;table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,44));table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,56));Controls.Add(table);
  foreach(var box in new[]{server,user,password,from,recipients}){box.TextAlign=HorizontalAlignment.Center;box.MaxLength=1000;}password.UseSystemPasswordChar=true;
  foreach(var box in new[]{enabled,down,up,tls,auth}){box.Text="Включено";box.AutoSize=false;box.TextAlign=ContentAlignment.MiddleCenter;}
  port.Minimum=1;port.Maximum=65535;port.TextAlign=HorizontalAlignment.Center;timeout.Minimum=5;timeout.Maximum=120;timeout.TextAlign=HorizontalAlignment.Center;
  Add("Почтовые уведомления",enabled,40);Add("Письмо при потере связи",down,40);Add("Письмо при восстановлении",up,40);
  clearPassword.Text="Очистить пароль";clearPassword.FlatStyle=FlatStyle.Flat;clearPassword.FlatAppearance.BorderSize=2;clearPassword.Click+=(s,e)=>{secret="";password.Clear();if(auth.Checked)enabled.Checked=false;clearPassword.Text="Пароль очищен";};
  Add("SMTP-сервер",server,40);Add("SMTP-порт",port,40);Add("Защита соединения STARTTLS",tls,40);Add("SMTP-аутентификация",auth,40);Add("Логин SMTP",user,40);Add("Пароль / пароль приложения\nПусто — оставить сохранённый",password,50);Add("Очистить сохранённый пароль",clearPassword,40);Add("Адрес отправителя",from,40);Add("Получатели (через ;)",recipients,40);Add("Тайм-аут отправки, с",timeout,40);
  foreach(var body in new[]{downBody,upBody}){body.Multiline=true;body.AcceptsReturn=true;body.ScrollBars=ScrollBars.Vertical;body.MaxLength=4000;body.WordWrap=true;}
  Add("Шаблон письма: потеря связи",downBody,125);Add("Шаблон письма: восстановление",upBody,125);
  var help=new Label{Text="Переменные: {Узел}, {Адрес}, {Порт}, {Метод}, {Потеря}, {Восстановление}, {Простой}. Имя узла — комментарий, если он задан, иначе адрес. Тема и обязательные данные события добавляются автоматически.",TextAlign=ContentAlignment.MiddleLeft};AddWide(help,85);
  AddWide(new Label{Text="Поддерживается SMTP с STARTTLS (обычно 587) и внутренний relay без аутентификации. SSL/TLS с подключением на порт 465 и OAuth2 не поддерживаются. Пароль хранится защищённым для текущего пользователя Windows.",TextAlign=ContentAlignment.MiddleLeft},80);
  test.Text="Отправить тестовое письмо";test.FlatStyle=FlatStyle.Flat;test.FlatAppearance.BorderSize=2;test.Click+=async(s,e)=>{MailProfile draft;try{draft=Read(false);string error=draft.Validate(true);if(error!=null)throw new InvalidOperationException(error);}catch(Exception ex){MessageBox.Show(ex.Message,"Настройки почты");return;}test.Enabled=false;status.Text="Отправка тестового письма…";string result;try{await Task.Run(()=>MailTransport.Send(new MailJob{Profile=draft,Subject="Monitor TEST: проверка уведомлений",Body="Тестовое письмо NetworkLight.\r\nВремя: "+DateTimeOffset.Now.ToString("dd.MM.yyyy HH:mm:ss zzz")}));result="Тестовое письмо принято SMTP-сервером.";}catch(Exception ex){result="Отправка не удалась: "+ex.GetType().Name+". "+ex.Message+"\nПроверьте сервер, STARTTLS, логин, пароль и адреса.";}if(!IsDisposed){test.Enabled=true;MessageBox.Show(result,"Проверка почты");UpdateStatus();}};AddWide(test,44);status.TextAlign=ContentAlignment.MiddleLeft;AddWide(status,65);
  refresh.Interval=1000;refresh.Tick+=(s,e)=>{if(test.Enabled)UpdateStatus();};refresh.Start();LoadProfile(profile??new MailProfile());
 }
 void Add(string caption,Control control,int height){int row=table.RowCount++;table.RowStyles.Add(new RowStyle(SizeType.Absolute,height));table.Controls.Add(new Label{Text=caption,Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleLeft,Margin=new Padding(10,4,6,4)},0,row);control.Dock=DockStyle.Fill;control.Margin=new Padding(6,6,18,6);table.Controls.Add(control,1,row);}
 public void AddWide(Control control,int height){int row=table.RowCount++;table.RowStyles.Add(new RowStyle(SizeType.Absolute,height));control.Dock=DockStyle.Fill;control.Margin=new Padding(10,4,18,4);table.Controls.Add(control,0,row);table.SetColumnSpan(control,2);}
 void UpdateStatus(){status.Text=queueStatus==null?"":queueStatus();}
 public void LoadProfile(MailProfile p){enabled.Checked=p.Enabled;down.Checked=p.OnDown;up.Checked=p.OnUp;tls.Checked=p.StartTls;auth.Checked=p.Authenticate;server.Text=p.Server;user.Text=p.User;secret=p.Secret;password.Clear();clearPassword.Text="Очистить пароль";from.Text=p.From;recipients.Text=p.Recipients;port.Value=Math.Max(1,Math.Min(65535,p.Port));timeout.Value=Math.Max(5,Math.Min(120,p.TimeoutSeconds));downBody.Text=p.DownTemplate;upBody.Text=p.UpTemplate;UpdateStatus();}
 public MailProfile Read(bool validate){var p=new MailProfile{Enabled=enabled.Checked,OnDown=down.Checked,OnUp=up.Checked,StartTls=tls.Checked,Authenticate=auth.Checked,Server=server.Text.Trim(),User=user.Text.Trim(),From=from.Text.Trim(),Recipients=recipients.Text.Trim(),Port=(int)port.Value,TimeoutSeconds=(int)timeout.Value,DownTemplate=downBody.Text,UpTemplate=upBody.Text,Secret=secret};if(password.Text.Length>0)p.Secret=MailProfile.Protect(password.Text);if(validate){string error=p.Validate(false);if(error!=null)throw new InvalidOperationException(error);}return p;}
 protected override void Dispose(bool disposing){if(disposing)refresh.Dispose();base.Dispose(disposing);}
}
}
