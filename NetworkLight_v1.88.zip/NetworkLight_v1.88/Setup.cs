﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;
internal static class SetupProgram {
 [STAThread] public static void Main(string[] args){if(args.Length==1&&args[0]=="--self-test"){try{ProductInstall.SelfTest();}catch(Exception ex){File.WriteAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"setup-test-error.txt"),ex.ToString());Environment.ExitCode=1;}return;}Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Application.Run(new InstallWindow());}
}
internal static class UninstallProgram {
 [STAThread] public static void Main(string[] args){Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);if(args.Length!=1){MessageBox.Show("Запустите удаление через меню Пуск → NetworkLight → Удалить NetworkLight.");Environment.ExitCode=1;return;}Application.Run(new RemoveWindow(args[0]));}
}
internal static class ProductInstall {
 internal const string ProductKey=@"Software\NetworkLight", UninstallKey=@"Software\Microsoft\Windows\CurrentVersion\Uninstall\NetworkLight", RunKey=@"Software\Microsoft\Windows\CurrentVersion\Run", Marker="networklight.install", Identity="NetworkLight:740af688-2a26-441c-b06a-71793e0b83c1";
 internal static readonly string DataFolder=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"NetworkLight");
 internal static readonly string[] Payload={"NetworkLight.exe","NetworkLight.exe.config","NetworkLight.ico","Uninstall.exe","Uninstall.ico","Uninstall.cmd"};
 internal static readonly string[] Legacy={"ShortcutSetup.exe","Uninstall.lnk"};
 internal static string MenuFolder {get{return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs),"NetworkLight");}}
 internal static string DesktopLink {get{return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),"NetworkLight.lnk");}}
 internal static string Normalize(string path){return Path.GetFullPath(path).TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar);}
 internal static bool Same(string a,string b){return !string.IsNullOrEmpty(a)&&!string.IsNullOrEmpty(b)&&string.Equals(Normalize(a),Normalize(b),StringComparison.OrdinalIgnoreCase);}
 internal static string InstalledFolder(){using(var key=Registry.CurrentUser.OpenSubKey(ProductKey)){var value=key==null?null:key.GetValue("InstallDir") as string;if(!string.IsNullOrWhiteSpace(value))return Normalize(value);}return File.Exists(Path.Combine(DataFolder,"NetworkLight.exe"))?DataFolder:null;}
 internal static string DefaultFolder(){return InstalledFolder()??Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Programs","NetworkLight");}
 internal static void SelfTest(){string root=Path.Combine(Path.GetTempPath(),"NetworkLight-tests-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);try{
  string clean=Path.Combine(root,"New");ValidateDestination(clean,root);Directory.CreateDirectory(clean);ValidateDestination(clean,root);File.WriteAllText(Path.Combine(clean,"unrelated.txt"),"retain");bool refused=false;try{ValidateDestination(clean,root);}catch(InvalidOperationException){refused=true;}if(!refused)throw new Exception("Nonempty foreign folder accepted");
  refused=false;try{ValidateDestination(Path.GetPathRoot(root),root);}catch(InvalidOperationException){refused=true;}if(!refused)throw new Exception("Drive root accepted");
  refused=false;try{ValidateDestination(root,root);}catch(InvalidOperationException){refused=true;}if(!refused)throw new Exception("Source folder accepted");
  if(!OwnedData("settings.xml.before-1.88")||!OwnedData("mail-queue.dat.bak")||OwnedData("unrelated.txt"))throw new Exception("Incorrect cleanup ownership");
  if(Payload.Any(n=>Path.GetFileName(n)!=n)||Payload.Distinct(StringComparer.OrdinalIgnoreCase).Count()!=Payload.Length)throw new Exception("Unsafe file manifest");
 }finally{Directory.Delete(root,true);}}
 internal static bool OwnedData(string name){return name.StartsWith("settings.xml",StringComparison.OrdinalIgnoreCase)||name.StartsWith("mail-queue.dat",StringComparison.OrdinalIgnoreCase)||name=="self-test-error.txt"||name=="ui-error.log";}
 internal static void ValidateDestination(string folder,string source){
  if(string.IsNullOrWhiteSpace(folder)||!Path.IsPathRooted(folder))throw new InvalidOperationException("Укажите полный путь к отдельной папке приложения.");
  folder=Normalize(folder);if(Same(folder,Path.GetPathRoot(folder))||Same(folder,source))throw new InvalidOperationException("Выберите отдельную папку приложения, не корень диска и не папку сборки.");
  if(Directory.Exists(folder)){if((File.GetAttributes(folder)&FileAttributes.ReparsePoint)!=0)throw new InvalidOperationException("Папка установки не должна быть ссылкой.");
   bool known=Same(folder,InstalledFolder())||Same(folder,DataFolder);
   foreach(var item in Directory.GetFileSystemEntries(folder)){string name=Path.GetFileName(item);if(!known||Directory.Exists(item)||!(Payload.Contains(name,StringComparer.OrdinalIgnoreCase)||Legacy.Contains(name,StringComparer.OrdinalIgnoreCase)||name==Marker||OwnedData(name)))throw new InvalidOperationException("Папка содержит посторонние файлы. Выберите пустую папку или отдельную подпапку NetworkLight.");}
  }
 }
 internal static Mutex LockMonitor(){bool created;var mutex=new Mutex(true,"Local\\NetworkLight-"+WindowsIdentity.GetCurrent().User.Value,out created);if(!created){mutex.Dispose();throw new InvalidOperationException("Закройте NetworkLight через меню трея → Выход, затем повторите действие.");}return mutex;}
 internal static void Install(string destination,bool desktop){string source=AppDomain.CurrentDomain.BaseDirectory;ValidateDestination(destination,source);destination=Normalize(destination);foreach(string file in Payload)if(!File.Exists(Path.Combine(source,file)))throw new FileNotFoundException("В установочном комплекте отсутствует "+file);
  using(var mutex=LockMonitor()){try{
   string previous=InstalledFolder();if(desktop&&File.Exists(DesktopLink)){string oldTarget=ShellLinks.Target(DesktopLink);if(!Same(oldTarget,Path.Combine(destination,"NetworkLight.exe"))&&(previous==null||!Same(oldTarget,Path.Combine(previous,"NetworkLight.exe"))))throw new InvalidOperationException("На рабочем столе уже есть другой ярлык NetworkLight. Снимите галочку или переименуйте существующий ярлык.");}bool hadAutorun;using(var key=Registry.CurrentUser.OpenSubKey(RunKey))hadAutorun=key!=null&&key.GetValue("NetworkLight")!=null;
   Directory.CreateDirectory(destination);string rollback=Path.Combine(Path.GetTempPath(),"NetworkLight-backup-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(rollback);var copied=new List<string>();bool committed=false;
   try{
    foreach(string file in Payload){string target=Path.Combine(destination,file);if(File.Exists(target))File.Copy(target,Path.Combine(rollback,file),true);File.Copy(Path.Combine(source,file),target,true);copied.Add(file);}
    File.WriteAllText(Path.Combine(destination,Marker),Identity,Encoding.UTF8);Directory.CreateDirectory(MenuFolder);
    string exe=Path.Combine(destination,"NetworkLight.exe"),icon=Path.Combine(destination,"NetworkLight.ico"),remove=Path.Combine(destination,"Uninstall.cmd"),removeIcon=Path.Combine(destination,"Uninstall.ico");
    ShellLinks.Create(Path.Combine(MenuFolder,"NetworkLight.lnk"),exe,destination,icon,"NetworkLight — монитор сети");ShellLinks.Create(Path.Combine(MenuFolder,"Удалить NetworkLight.lnk"),remove,destination,removeIcon,"Удалить NetworkLight");
    if(desktop)ShellLinks.Create(DesktopLink,exe,destination,icon,"NetworkLight — монитор сети");else DeleteOwnedLink(DesktopLink,previous,destination);
    DeleteOwnedLink(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs),"NetworkLight.lnk"),previous,destination);DeleteOwnedLink(Path.Combine(MenuFolder,"Uninstall NetworkLight.lnk"),previous,destination);
    using(var key=Registry.CurrentUser.CreateSubKey(ProductKey)){key.SetValue("InstallDir",destination);key.SetValue("Version","1.88");key.SetValue("DesktopShortcut",desktop?1:0,RegistryValueKind.DWord);}
    using(var key=Registry.CurrentUser.CreateSubKey(UninstallKey)){key.SetValue("DisplayName","NetworkLight");key.SetValue("DisplayVersion","1.88");key.SetValue("DisplayIcon",icon);key.SetValue("InstallLocation",destination);key.SetValue("UninstallString","\""+Environment.GetEnvironmentVariable("ComSpec")+"\" /d /c \"\""+remove+"\"\"");key.SetValue("NoModify",1,RegistryValueKind.DWord);key.SetValue("NoRepair",1,RegistryValueKind.DWord);}
    if(hadAutorun)using(var key=Registry.CurrentUser.CreateSubKey(RunKey))key.SetValue("NetworkLight","\""+exe+"\" --tray");
    committed=true;
   }finally{
    if(!committed){foreach(string file in copied){string backup=Path.Combine(rollback,file),target=Path.Combine(destination,file);if(File.Exists(backup))File.Copy(backup,target,true);else if(File.Exists(target))File.Delete(target);}if(!Same(destination,previous)&&File.Exists(Path.Combine(destination,Marker)))File.Delete(Path.Combine(destination,Marker));}
    Directory.Delete(rollback,true);
   }
   if(previous!=null&&!Same(previous,destination))RemoveBinaries(previous);else foreach(string name in Legacy){string file=Path.Combine(destination,name);if(File.Exists(file))File.Delete(file);}
   ShellLinks.Refresh();
  }finally{mutex.ReleaseMutex();}}
 }
 internal static void DeleteOwnedLink(string file,string previous,string current){if(!File.Exists(file))return;string target=ShellLinks.Target(file);if((previous!=null&&(Same(target,Path.Combine(previous,"NetworkLight.exe"))||Same(target,Path.Combine(previous,"Uninstall.cmd"))))||(current!=null&&(Same(target,Path.Combine(current,"NetworkLight.exe"))||Same(target,Path.Combine(current,"Uninstall.cmd")))))File.Delete(file);}
 internal static void RemoveBinaries(string folder){foreach(string name in Payload.Concat(Legacy).Concat(new[]{Marker})){string path=Path.Combine(folder,name);if(File.Exists(path))File.Delete(path);}RemoveEmpty(folder);}
 internal static void RemoveEmpty(string folder){if(Directory.Exists(folder)&&Directory.GetFileSystemEntries(folder).Length==0)Directory.Delete(folder);}
 internal static string Uninstall(string folder,bool keepSettings){folder=Normalize(folder);string marker=Path.Combine(folder,Marker);if(!Same(folder,InstalledFolder())||!File.Exists(marker)||File.ReadAllText(marker,Encoding.UTF8)!=Identity)throw new InvalidOperationException("Не удалось подтвердить папку установленного NetworkLight. Повторите установку 1.88 для восстановления деинсталлятора.");
  if((File.GetAttributes(folder)&FileAttributes.ReparsePoint)!=0)throw new InvalidOperationException("Папка приложения заменена ссылкой; удаление остановлено.");
  using(var mutex=LockMonitor()){try{
   foreach(string name in new[]{"NetworkLight.lnk","Удалить NetworkLight.lnk","Uninstall NetworkLight.lnk"})DeleteOwnedLink(Path.Combine(MenuFolder,name),folder,null);RemoveEmpty(MenuFolder);DeleteOwnedLink(DesktopLink,folder,null);DeleteOwnedLink(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs),"NetworkLight.lnk"),folder,null);
   using(var key=Registry.CurrentUser.OpenSubKey(RunKey,true)){if(key!=null)key.DeleteValue("NetworkLight",false);}
   foreach(string dir in new[]{DataFolder,folder}.Distinct(StringComparer.OrdinalIgnoreCase))if(Directory.Exists(dir)){if((File.GetAttributes(dir)&FileAttributes.ReparsePoint)!=0)throw new InvalidOperationException("Папка настроек заменена ссылкой; удаление остановлено.");foreach(string file in Directory.GetFiles(dir)){string name=Path.GetFileName(file);bool setting=name.StartsWith("settings.xml",StringComparison.OrdinalIgnoreCase);if(OwnedData(name)&&(!setting||!keepSettings))File.Delete(file);}}
   RemoveBinaries(folder);RemoveEmpty(DataFolder);Registry.CurrentUser.DeleteSubKeyTree(UninstallKey,false);Registry.CurrentUser.DeleteSubKeyTree(ProductKey,false);ShellLinks.Refresh();
   string message=keepSettings?"Приложение удалено. Настройки сохранены: "+DataFolder:"Приложение и его настройки удалены.";
   if(Directory.Exists(folder)&&(!keepSettings||!Same(folder,DataFolder)))message+="\nВ папке остались посторонние файлы; они не удалялись: "+folder;
   return message;
  }finally{mutex.ReleaseMutex();}}
 }
}
internal sealed class InstallWindow:Form {
 readonly TextBox path=new TextBox();readonly CheckBox desktop=new CheckBox();
 internal InstallWindow(){Text="Установка NetworkLight 1.88";Font=new Font("Segoe UI",10);ClientSize=new Size(640,270);FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;StartPosition=FormStartPosition.CenterScreen;
  Controls.Add(new Label{Text="Папка установки",Left=20,Top=20,Width=590});path.SetBounds(20,50,490,30);path.Text=ProductInstall.DefaultFolder();Controls.Add(path);var browse=new Button{Text="Обзор…",Left=520,Top=48,Width=100,Height=32};browse.Click+=(s,e)=>{using(var dialog=new FolderBrowserDialog{Description="Выберите отдельную папку NetworkLight",SelectedPath=path.Text,ShowNewFolderButton=true})if(dialog.ShowDialog(this)==DialogResult.OK)path.Text=dialog.SelectedPath;};Controls.Add(browse);
  desktop.Text="Создать ярлык на рабочем столе";desktop.Checked=true;desktop.SetBounds(20,98,580,30);Controls.Add(desktop);Controls.Add(new Label{Text="В меню «Пуск» будет папка NetworkLight с запуском и удалением.\nНастройки сохраняются отдельно в профиле пользователя.",Left=20,Top=140,Width=600,Height=50});
  var install=new Button{Text="Установить",Left=370,Top=215,Width=130,Height=36,BackColor=Color.SeaGreen,ForeColor=Color.White,FlatStyle=FlatStyle.Flat};install.Click+=(s,e)=>{try{ProductInstall.Install(path.Text,desktop.Checked);MessageBox.Show(this,"Установка завершена. Откройте Пуск → NetworkLight → NetworkLight.\nАвтозапуск можно включить в настройках приложения.","NetworkLight");DialogResult=DialogResult.OK;Close();}catch(Exception ex){MessageBox.Show(this,ex.Message,"Установка не завершена",MessageBoxButtons.OK,MessageBoxIcon.Error);}};Controls.Add(install);var cancel=new Button{Text="Отмена",Left=510,Top=215,Width=110,Height=36};cancel.Click+=(s,e)=>Close();Controls.Add(cancel);AcceptButton=install;CancelButton=cancel;
 }
}
internal sealed class RemoveWindow:Form {
 internal RemoveWindow(string folder){Text="Удаление NetworkLight 1.88";Font=new Font("Segoe UI",10);ClientSize=new Size(620,250);FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;StartPosition=FormStartPosition.CenterScreen;Controls.Add(new Label{Text="Удалить NetworkLight из папки:\n"+folder,Left=20,Top=20,Width=580,Height=65});var keep=new CheckBox{Text="Сохранить настройки приложения и узлов",Checked=true,Left=20,Top=95,Width=570,Height=30};Controls.Add(keep);Controls.Add(new Label{Text="Ярлыки, автозапуск и очередь писем будут удалены.\nЕсли снять галочку, настройки и их резервные копии тоже удалятся.",Left=20,Top=135,Width=580,Height=50});var remove=new Button{Text="Удалить",Left=365,Top=200,Width=110,Height=34};remove.Click+=(s,e)=>{try{string result=ProductInstall.Uninstall(folder,keep.Checked);MessageBox.Show(this,result,"NetworkLight");Environment.ExitCode=0;Close();}catch(Exception ex){Environment.ExitCode=1;MessageBox.Show(this,ex.Message,"Удаление не завершено",MessageBoxButtons.OK,MessageBoxIcon.Error);}};Controls.Add(remove);var cancel=new Button{Text="Отмена",Left=490,Top=200,Width=110,Height=34};cancel.Click+=(s,e)=>Close();Controls.Add(cancel);CancelButton=cancel;}
}
