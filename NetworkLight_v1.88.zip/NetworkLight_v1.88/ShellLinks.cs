﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
internal static class ShellLinks {
 [DllImport("shell32.dll")] static extern void SHChangeNotify(uint eventId,uint flags,IntPtr item1,IntPtr item2);
 internal static void Refresh(){SHChangeNotify(0x08000000,0,IntPtr.Zero,IntPtr.Zero);}
 internal static void Create(string path,string target,string folder,string icon,string description){if(!File.Exists(target)||!File.Exists(icon))throw new FileNotFoundException("Не найден файл приложения или иконки для ярлыка.");object instance=new ShellLink();try{var link=(IShellLinkW)instance;link.SetPath(target);link.SetWorkingDirectory(folder);link.SetDescription(description);link.SetIconLocation(icon,0);link.SetShowCmd(1);((IPersistFile)instance).Save(path,true);}finally{Marshal.FinalReleaseComObject(instance);}if(!ProductInstall.Same(Target(path),target)||!ProductInstall.Same(IconPath(path),icon))throw new IOException("Не удалось проверить созданный ярлык или его иконку: "+path);}
 internal static string IconPath(string path){object instance=new ShellLink();try{((IPersistFile)instance).Load(path,0);var text=new StringBuilder(32768);int index;((IShellLinkW)instance).GetIconLocation(text,text.Capacity,out index);return text.ToString();}finally{Marshal.FinalReleaseComObject(instance);}}
 internal static string Target(string path){object instance=new ShellLink();try{((IPersistFile)instance).Load(path,0);var text=new StringBuilder(32768);((IShellLinkW)instance).GetPath(text,text.Capacity,IntPtr.Zero,4);return text.ToString();}finally{Marshal.FinalReleaseComObject(instance);}}
 [ComImport,Guid("00021401-0000-0000-C000-000000000046")] class ShellLink {}
 [ComImport,Guid("000214F9-0000-0000-C000-000000000046"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)] interface IShellLinkW {
  void GetPath([Out,MarshalAs(UnmanagedType.LPWStr)] StringBuilder file,int max,IntPtr findData,uint flags);
  void GetIDList(out IntPtr idList);void SetIDList(IntPtr idList);
  void GetDescription([Out,MarshalAs(UnmanagedType.LPWStr)] StringBuilder name,int max);
  void SetDescription([MarshalAs(UnmanagedType.LPWStr)] string name);
  void GetWorkingDirectory([Out,MarshalAs(UnmanagedType.LPWStr)] StringBuilder dir,int max);
  void SetWorkingDirectory([MarshalAs(UnmanagedType.LPWStr)] string dir);
  void GetArguments([Out,MarshalAs(UnmanagedType.LPWStr)] StringBuilder args,int max);
  void SetArguments([MarshalAs(UnmanagedType.LPWStr)] string args);
  void GetHotkey(out short hotkey);void SetHotkey(short hotkey);
  void GetShowCmd(out int show);void SetShowCmd(int show);
  void GetIconLocation([Out,MarshalAs(UnmanagedType.LPWStr)] StringBuilder icon,int max,out int index);
  void SetIconLocation([MarshalAs(UnmanagedType.LPWStr)] string icon,int index);
  void SetRelativePath([MarshalAs(UnmanagedType.LPWStr)] string path,uint reserved);
  void Resolve(IntPtr hwnd,uint flags);void SetPath([MarshalAs(UnmanagedType.LPWStr)] string path);
 }
}
