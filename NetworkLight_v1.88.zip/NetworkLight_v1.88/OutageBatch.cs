﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace NetworkLight {
// One incident owns the two-second collection window and any confirmation probes.
public sealed class OutageBatch {
 public bool Active, Confirming; public long Started;public int Generation;
 public readonly List<Node> Participants=new List<Node>();
 readonly HashSet<Node> fallen=new HashSet<Node>();readonly Dictionary<Node,bool?> results=new Dictionary<Node,bool?>();bool anyReply;
 public void Reset(){Active=Confirming=anyReply=false;Participants.Clear();fallen.Clear();results.Clear();Generation++;}
 public void Down(Node node,long now,IEnumerable<Node> running){
  if(!Active){Reset();Active=true;Started=now;Participants.AddRange(running);}
  if(!Participants.Contains(node))return;fallen.Add(node);
  if(!Confirming&&fallen.Count*2>=Participants.Count){Confirming=true;foreach(var n in Participants)if(!fallen.Contains(n))results[n]=null;}
 }
 public bool HasAudibleOutage {get{return Participants.Any(n=>n.Target.Running&&n.Target.SoundEnabled&&n.Alarm.Offline);}}
 public IEnumerable<Node> Pending(){return results.Where(p=>!p.Value.HasValue).Select(p=>p.Key).ToArray();}
 public void Report(Node node,bool success,long requestStarted){if(!Active||requestStarted<Started||!Participants.Contains(node))return;if(success)anyReply=true;if(results.ContainsKey(node)&&!results[node].HasValue)results[node]=success;}
 // 0 = still pending; -1 = recovered before decision; 3 = partial; 4 = all down.
 public int Finish(long now){if(!Active||now-Started<2000||results.Any(p=>!p.Value.HasValue))return 0;
  bool stillDown=fallen.Any(n=>n.Alarm.Offline);if(!stillDown){Active=false;return -1;}
  bool all=Participants.All(n=>n.Alarm.Offline);
  if(Confirming)all=!anyReply&&fallen.All(n=>n.Alarm.Offline)&&results.All(p=>p.Value==false);
  if(all)foreach(var n in Participants){n.Alarm.ConfirmOffline();n.Dirty=true;}
  Active=false;return all?4:3;
 }
}
}

namespace NetworkLight {
// Recovery owns its notification; the regular notifier cannot emit a second tune.
public sealed class RecoveryBatch {
 bool commonOutage;
 public void ForgetHistory(){commonOutage=false;}
 public void NoteCommonOutage(){commonOutage=true;}
 public bool HasAudibleRecovery {get{return recovered.Any(n=>n.Target.SoundEnabled&&!n.Alarm.Offline&&n.Alarm.LastSuccess);}}
 public bool Active, Confirming;public long Started;public int Generation;
 public readonly List<Node> Participants=new List<Node>();
 readonly HashSet<Node> recovered=new HashSet<Node>();readonly Dictionary<Node,bool?> results=new Dictionary<Node,bool?>();
 public void Reset(){Active=Confirming=false;Participants.Clear();recovered.Clear();results.Clear();Generation++;}
 public void Up(Node node,long now,IEnumerable<Node> running){
  if(!Active){Reset();Active=true;Started=now;Participants.AddRange(running);}
  if(!Participants.Contains(node))return;if(Participants.All(n=>n==node||n.Alarm.Offline))commonOutage=true;recovered.Add(node);
  if(!Confirming&&recovered.Count*2>=Participants.Count){Confirming=true;foreach(var n in Participants)if(n.Alarm.Offline&&!recovered.Contains(n))results[n]=null;}
 }
 public IEnumerable<Node> Pending(){return results.Where(p=>!p.Value.HasValue).Select(p=>p.Key).ToArray();}
 public void Report(Node node,bool success,long requestStarted){if(!Active||requestStarted<Started)return;if(results.ContainsKey(node)&&!results[node].HasValue)results[node]=success;}
 public int Finish(long now){if(!Active||now-Started<2000||results.Any(p=>!p.Value.HasValue))return 0;
  Active=false;if(!recovered.Any(n=>!n.Alarm.Offline&&n.Alarm.LastSuccess))return -1;
  bool allUp=Participants.All(n=>n.Alarm.HasSample&&n.Alarm.LastSuccess&&!n.Alarm.Offline);bool doubleTune=commonOutage&&allUp;if(allUp)commonOutage=false;return doubleTune?6:5;
 }
}
}
