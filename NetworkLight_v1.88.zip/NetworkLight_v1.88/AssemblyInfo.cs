﻿using System.Reflection;
[assembly:AssemblyTitle("NetworkLight")]
[assembly:AssemblyDescription("ICMP and TCP availability monitor with user-configured email alerts")]
[assembly:AssemblyProduct("NetworkLight")]
[assembly:AssemblyVersion("1.88.0.0")]
[assembly:AssemblyFileVersion("1.88.0.0")]
